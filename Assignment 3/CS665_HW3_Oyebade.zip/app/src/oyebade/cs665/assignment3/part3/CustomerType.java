package oyebade.cs665.part3;

// creating the customer type constants
public enum CustomerType {
    // standard customer
    Standard,
    // preferred customer
    Preferred,
    // business customer
    Business
}

package oyebade.cs665.part3;

// creating a customer class
public abstract class Customer {
    // to return customer
    public String toString() {
        return "**Customer**";
    }
}

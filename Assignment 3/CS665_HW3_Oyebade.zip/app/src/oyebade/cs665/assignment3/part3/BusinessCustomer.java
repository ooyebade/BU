package oyebade.cs665.part3;

public class BusinessCustomer extends Customer {

    public String toString() {
        return super.toString() + "::" + "Business Customer";
    }
}

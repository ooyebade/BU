package oyebade.cs665.part3;


public class StandardCustomer extends Customer {

    public String toString() {
        return super.toString() + "::" + "Standard Customer";
    }
}

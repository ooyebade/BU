package oyebade.cs665.part3;


public class PreferredCustomer extends Customer {

    public String toString() {
        return super.toString() + "::" + "Preferred Customer";
    }
}

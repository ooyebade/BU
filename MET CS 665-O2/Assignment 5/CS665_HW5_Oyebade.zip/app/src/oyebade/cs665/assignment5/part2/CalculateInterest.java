package oyebade.cs665.part2;

public interface CalculateInterest {

    //
    public double calcInterest(double balance, double rate);
}

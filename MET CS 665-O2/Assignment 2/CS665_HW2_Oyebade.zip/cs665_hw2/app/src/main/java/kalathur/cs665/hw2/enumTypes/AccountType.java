package kalathur.cs665.hw2.enumTypes;

public enum AccountType {
    Checking,
    Savings,
    CD
}


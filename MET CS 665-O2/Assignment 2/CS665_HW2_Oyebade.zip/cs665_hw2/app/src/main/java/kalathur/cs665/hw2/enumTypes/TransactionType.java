package kalathur.cs665.hw2.enumTypes;

public enum TransactionType {
    Deposit,
    Withdraw,
    Transfer
}

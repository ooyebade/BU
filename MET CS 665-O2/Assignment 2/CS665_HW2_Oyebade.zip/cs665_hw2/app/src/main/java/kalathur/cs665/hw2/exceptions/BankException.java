package kalathur.cs665.hw2.exceptions;

public class BankException extends RuntimeException {
    public BankException(String msg) {
        super(msg);
    }
}

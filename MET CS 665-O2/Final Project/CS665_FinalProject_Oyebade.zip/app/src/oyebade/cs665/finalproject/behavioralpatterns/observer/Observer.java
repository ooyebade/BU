package oyebade.cs665.behavioral.observer;

interface Observer {
    // defining an update interface for objects that should be notified of changes in the subject
     void update(String s);
}

package oyebade.cs665.structural.facade;

public class Student {

    String studentName;

    public Student(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentName() {
        return studentName;
    }
}

module.exports = function addEmployee(req , res , next) {
		
	// Fill in the code

	// Add Employee
	res.render('addEmployeeView', {title: "Add a New Employee"});
};

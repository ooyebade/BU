# -*- coding: utf-8 -*-

"""
Elizabeth Oyebade
Class: CS 521 - Spring 2
Date: 03.24.2021
Homework Problem #2.1.2
Prompt users for their input then print their input 
as a string, an integer, and a floating-point value.   
"""

# Ask user to enter a value
val = input("Enter your value: ")
# Print the given value into a string
print("String Value: ", str(val))
# Print the given value as an integer
print("Integer Value: ", int(val))
# Print the given as a float
print("Float Value: ", float(val))

"""
Entering int and float data types will print without generating any errors.

"""
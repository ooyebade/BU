<?php
// Set up the database connection
define('db_host','localhost');
// Database username
define('db_user','cs602_term');
// Database password
define('db_pass','cs602_secret');
// Database name
define('db_name','cs602_term_projectdb');

 
// This will change the title on the website
define('site_name','Shop-Shopping Kart');

define('currency_code','&dollar;');
// logo
define('bu_logo','imgs/bu-campus.jpg');

// Account required for checkout?
define('account_required',true);

define('rewrite_url',false);

?>
